public enum TestType
{
    FIRST,
    SECOND
}